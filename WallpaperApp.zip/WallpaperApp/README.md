# WallpaperApp

Kotlin ile yazılmış basit bir Android duvar kağıdı uygulaması. Görselleri [picsum.photos](https://picsum.photos) üzerinden listeler, önizleme gösterir ve seçilen görseli **ana ekran**, **kilit ekranı** veya **ikisi birden** olarak ayarlar.

## Özellikler
- 2 sütunlu duvar kağıdı galerisi (RecyclerView + Coil)
- Tam ekran önizleme
- Ana ekran / kilit ekranı / ikisi için duvar kağıdı ayarlama (`WallpaperManager`)
- API anahtarı gerekmez

## Gereksinimler
- Android Studio (Koala veya yeni), JDK 17
- minSdk 24, targetSdk 34

## Çalıştırma
1. Projeyi klonla: `git clone <repo-url>`
2. Android Studio ile aç; Gradle senkronizasyonu `gradle/wrapper` dosyalarını otomatik oluşturur.
3. Cihaz veya emülatörde `app` modülünü çalıştır.

Komut satırı: `gradle wrapper --gradle-version 8.7` ardından `./gradlew assembleDebug`.

## Proje yapısı
```
app/src/main/java/com/example/wallpaperapp/
├── MainActivity.kt        # galeri
├── PreviewActivity.kt     # önizleme + duvar kağıdı ayarlama
├── Wallpaper.kt           # model ve kaynak (görsel URL'leri)
└── WallpaperAdapter.kt    # liste adaptörü
```

## Kendi görsellerini kullanma
`Wallpaper.kt` içindeki `WallpaperRepository` ve `url()` fonksiyonunu kendi API'nle veya sabit bir liste ile değiştir.

## GitHub'a yükleme
```
git init
git add .
git commit -m "İlk sürüm"
git branch -M main
git remote add origin https://github.com/KULLANICI/WallpaperApp.git
git push -u origin main
```
`.github/workflows/android.yml` her push'ta debug APK derler ve Actions çıktısı olarak yükler.

## Lisans
MIT
