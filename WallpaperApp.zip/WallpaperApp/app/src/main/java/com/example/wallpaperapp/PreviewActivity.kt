package com.example.wallpaperapp

import android.app.WallpaperManager
import android.graphics.Bitmap
import android.graphics.drawable.BitmapDrawable
import android.os.Build
import android.os.Bundle
import android.view.View
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import coil.imageLoader
import coil.load
import coil.request.ImageRequest
import coil.request.SuccessResult
import com.example.wallpaperapp.databinding.ActivityPreviewBinding
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

class PreviewActivity : AppCompatActivity() {

    private lateinit var binding: ActivityPreviewBinding
    private lateinit var wallpaper: Wallpaper

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityPreviewBinding.inflate(layoutInflater)
        setContentView(binding.root)

        wallpaper = Wallpaper(intent.getStringExtra(EXTRA_SEED) ?: "wallpaper1")
        binding.preview.load(wallpaper.fullUrl()) { crossfade(true) }

        binding.btnHome.setOnClickListener { apply(WallpaperManager.FLAG_SYSTEM) }
        binding.btnLock.setOnClickListener { apply(WallpaperManager.FLAG_LOCK) }
        binding.btnBoth.setOnClickListener {
            apply(WallpaperManager.FLAG_SYSTEM or WallpaperManager.FLAG_LOCK)
        }
    }

    private fun apply(flags: Int) {
        setLoading(true)
        lifecycleScope.launch {
            try {
                val request = ImageRequest.Builder(this@PreviewActivity)
                    .data(wallpaper.fullUrl())
                    .allowHardware(false)
                    .build()
                val result = imageLoader.execute(request)
                val bitmap: Bitmap = ((result as? SuccessResult)?.drawable as? BitmapDrawable)?.bitmap
                    ?: throw IllegalStateException("Görsel indirilemedi")

                withContext(Dispatchers.IO) {
                    val manager = WallpaperManager.getInstance(this@PreviewActivity)
                    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.N) {
                        manager.setBitmap(bitmap, null, true, flags)
                    } else {
                        manager.setBitmap(bitmap)
                    }
                }
                toast(getString(R.string.wallpaper_set))
            } catch (e: Exception) {
                toast(getString(R.string.wallpaper_error))
            } finally {
                setLoading(false)
            }
        }
    }

    private fun setLoading(loading: Boolean) {
        binding.progress.visibility = if (loading) View.VISIBLE else View.GONE
        binding.buttons.isEnabled = !loading
        binding.btnHome.isEnabled = !loading
        binding.btnLock.isEnabled = !loading
        binding.btnBoth.isEnabled = !loading
    }

    private fun toast(msg: String) = Toast.makeText(this, msg, Toast.LENGTH_SHORT).show()

    companion object {
        const val EXTRA_SEED = "seed"
    }
}
