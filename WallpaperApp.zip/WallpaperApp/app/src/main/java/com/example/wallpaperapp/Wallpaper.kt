package com.example.wallpaperapp

/**
 * Wallpaper kaynağı: picsum.photos (API anahtarı gerekmez).
 * Kendi kaynağınızı kullanmak için [url] fonksiyonunu değiştirin.
 */
data class Wallpaper(val seed: String) {
    fun thumbUrl() = url(400, 700)
    fun fullUrl() = url(1080, 1920)
    private fun url(w: Int, h: Int) = "https://picsum.photos/seed/$seed/$w/$h"
}

object WallpaperRepository {
    fun getAll(): List<Wallpaper> =
        (1..40).map { Wallpaper("wallpaper$it") }
}
