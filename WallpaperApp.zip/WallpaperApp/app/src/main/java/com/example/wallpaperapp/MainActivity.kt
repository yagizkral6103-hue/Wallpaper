package com.example.wallpaperapp

import android.content.Intent
import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.GridLayoutManager
import com.example.wallpaperapp.databinding.ActivityMainBinding

class MainActivity : AppCompatActivity() {

    private lateinit var binding: ActivityMainBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)
        setSupportActionBar(binding.toolbar)

        binding.recycler.layoutManager = GridLayoutManager(this, 2)
        binding.recycler.adapter = WallpaperAdapter(WallpaperRepository.getAll()) { wallpaper ->
            startActivity(
                Intent(this, PreviewActivity::class.java)
                    .putExtra(PreviewActivity.EXTRA_SEED, wallpaper.seed)
            )
        }
    }
}
